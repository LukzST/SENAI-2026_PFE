let nota1 = 8.5;
let nota2 = 10;
let nota3 = 7.5;

let media = (nota1 + nota2 + nota3) / 3;

console.log('A média das notas é ' + media);