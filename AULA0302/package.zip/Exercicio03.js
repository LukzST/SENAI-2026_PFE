let nome = 'Lucas';
console.log('Olá, ' + nome + '!')