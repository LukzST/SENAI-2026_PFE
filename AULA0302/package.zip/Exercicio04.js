const prompt = require('prompt-sync')();
let a = prompt('Digite um número: ');
let b = prompt('Digite outro número: ');

console.log(a + b);