// var nome;
// console.log(nome);

// nome = 'Lucas';
// console.log(nome);

// let numero = '10';
// console.log(Number(numero) + 20);

// let numero = 10;
// console.log(numero + 20);
// console.log(typeof numero);

// const CPF = '123.456.789-00';
// console.log(CPF);

let nome = 'Lucas'; // string
let idade = 17; // number
let altura = 1.83; // number (Float)
let ativo = true; // boolean
let matricula; // undefined
let salario = null; // null

let variavel; // string
const constante = 0; // constante number